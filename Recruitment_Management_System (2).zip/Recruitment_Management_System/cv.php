<!DOCTYPE html>
<?php
    session_start();
    include('admin/db_connect.php');
    ob_start();
    $query = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
     foreach ($query as $key => $value) {
      if(!is_numeric($key))
        $_SESSION['setting_'.$key] = $value;
    }
    ob_end_flush();
    include('header.php');

	
    ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Parser</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
        }
        #file-input {
            margin-bottom: 20px;
        }
        #submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        #submit-btn:hover {
            background-color: #45a049;
        }
        #result {
            margin-top: 20px;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }
        .resume-item {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .resume-item h3 {
            margin-top: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>CV Parser</h1>
        <form id="upload-form" enctype="multipart/form-data">
            <input type="file" id="file-input" name="resumes[]" multiple accept=".pdf,.doc,.docx">
            <button type="submit" id="submit-btn">Parse CVs</button>
        </form>
        <div id="result"></div>
    </div>

    <script>
        document.getElementById('upload-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            var formData = new FormData(this);
            
            fetch('parse_cv.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                var resultDiv = document.getElementById('result');
                resultDiv.innerHTML = '';
                
                if (data.success) {
                    data.response.resumedetails.forEach(resume => {
                        var resumeDiv = document.createElement('div');
                        resumeDiv.className = 'resume-item';
                        resumeDiv.innerHTML = `
                            <h3>${resume.FullName}</h3>
                            <p>Email: ${resume.Email}</p>
                            <p>Phone: ${resume.PhoneNumber}</p>
                            <p>Experience: ${resume.TotalExperienceInMonths} months</p>
                            <p>Recent Company: ${resume.RecentCompany}</p>
                            <p>Job Profile: ${resume.JobProfile}</p>
                            <p>Skills: ${resume.Skills.split('  ').join(', ')}</p>
                        `;
                        resultDiv.appendChild(resumeDiv);
                    });
                } else {
                    resultDiv.innerHTML = `<p>Error: ${data.message}</p>`;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('result').innerHTML = '<p>An error occurred. Please try again.</p>';
            });
        });
    </script>
</body>
</html>