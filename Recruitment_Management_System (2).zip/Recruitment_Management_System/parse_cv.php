<?php
// Set the content type to application/json
header('Content-Type: application/json');

// Check if files were uploaded
if (!isset($_FILES['resumes'])) {
    echo json_encode(['success' => false, 'message' => 'No resumes uploaded.']);
    exit;
}

// Initialize cURL
$curl = curl_init();

$postFields = array();
foreach ($_FILES['resumes']['tmp_name'] as $index => $tmpName) {
    $postFields['resumes[]'] = new CURLFile(
        $tmpName,
        $_FILES['resumes']['type'][$index],
        $_FILES['resumes']['name'][$index]
    );
}

// Set cURL options
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api.hirelake.ai:9443/api/cv-parser',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $postFields,
    CURLOPT_HTTPHEADER => array(
        'clientId: 27a9075feb66ab7ea19a50b14bc41c3473ed6a93',
        'clientSecret: 4o2nnr22tj_vAc_GiXK4xIaaCX2eu3bHR1c-xVxG'
    ),
));

// Execute cURL and capture the response
$response = curl_exec($curl);

// Check for cURL errors
if ($response === false) {
    // Log the error message
    $error = curl_error($curl);
    curl_close($curl);
    echo json_encode(['success' => false, 'message' => 'Curl error: ' . $error]);
    exit;
}

// Close cURL session
curl_close($curl);

// Decode the response (assuming the API returns JSON)
$parsedResponse = json_decode($response, true);

// Check if the response is valid JSON
if ($parsedResponse === null) {
    // Log an error if the response isn't valid JSON
    echo json_encode(['success' => false, 'message' => 'Invalid JSON response from API', 'response' => $response]);
    exit;
}

// Output the parsed JSON response
echo json_encode(['success' => true, 'response' => $parsedResponse]);
?>
