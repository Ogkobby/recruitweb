<?php
  header('Content-type: text/html; charset=utf-8'); 
  include "class.recruiter.php";	
  include "class.rchilli.php";	
  $upload_result='';		
  $upload= new Recruiter();
  session_start();  // Start the session
  if(!isset($_SESSION['login_id']))
    header('location:login.php');
 include('./header.php'); 
 // include('./auth.php'); 
 include 'navbar.php'
?>
<style>
/* General Styles */
body {
    margin-left: 250px; /* Set the margin-left equal to the width of the sidebar */
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    color: #333;
}

/* Form Container */
form {
    width: 50%;
    margin: 50px auto;
    padding: 20px;
    background-color: #ffffff;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

form input[type="file"] {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
}

form input[type="submit"] {
    background-color: #3291e6;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
}

form input[type="submit"]:hover {
    background-color: #7bc1ff;
}

/* Responsive Design */
@media (max-width: 768px) {
    .navbar {
        width: 100px; /* Adjust the sidebar width for smaller screens */
    }
    body {
        margin-left: 100px; /* Adjust the margin for smaller screens */
    }
    form {
        width: 90%;
    }
}


/* Textarea Styles */
textarea {
    width: 100%;
    height: 200px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    resize: none;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

table, th, td {
    border: 1px solid #ddd;
}

table th, table td {
    padding: 12px;
    text-align: left;
}

table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

table tr:nth-child(even) {
    background-color: #f9f9f9;
}

/* Error/Success Messages */
.msg {
    text-align: center;
    padding: 10px;
    margin: 20px 0;
    border-radius: 4px;
    font-size: 14px;
}

.msg.error {
    background-color: #ffdddd;
    color: #a33;
}

.msg.success {
    background-color: #ddffdd;
    color: #3a3;
}

/* Image Display */
img {
    display: block;
    margin: 20px auto;
    border: 1px solid #ccc;
    padding: 10px;
    background-color: #fff;
    border-radius: 8px;
}

/* Responsive Design */
@media (max-width: 768px) {
    form {
        width: 90%;
        margin: 20px auto;
    }

    textarea {
        height: 150px;
    }

    img {
        width: 100px;
        height: 100px;
    }
    
}
</style>
<link rel='stylesheet' type='text/css' media='screen' href='assets/css/style.css'>
<body>
<nav class="navbar navbar-light fixed-top bg-primary" style="padding:0;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
  		<div class="col-md-1 float-left" style="display: flex;">
  			<div class="logo">
  				<span class="fa fa-hands-helping"></span>
  			</div>
  		</div>
      <div class="col-md-4 float-left text-white">
        <large><b>Recruitment Management System</b></large>
      </div>
	  	<div class="col-md-2 float-right text-white">
	  		<a href="ajax.php?action=logout" class="text-white"><?php echo $_SESSION['login_name'] ?> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav>
</body>
	<form action="" method="post" name="uploadform" enctype="multipart/form-data" >
		<input type="hidden" name="filesubmitted" value="yes">
		Upload File: <input name="resumecontent" id="resumecontent" type="file" size="9"><br />	
		<input type="submit" src="images/submit.gif" name="login" alt="Submit" value="Submit" >
	</form>
<?php
	if(isset($_POST['filesubmitted'])) {				
		 echo $upload_result = $upload->SaveUplodedFile();		 
	}	
	
	


?>