<?php

class RchilliService
{
	
	
	public function __construct()
	{

	}
	public function resumeParseBinary($encode64,$type )
	{
	 //Your Api Link
	 $APIURL="https://rest.rchilli.com/RChilliParser/Rchilli/parseResumeBinary";
	  try
	  {
		 $encode64 = base64_encode($encode64);		   
		 $key='OOHR2I0T';
		 $version = "8.0.0";
		 $subUserId = "Kobby Bremansu";
		 $data = array(
					"filedata" => $encode64,
					"filename" => $type,
					"userkey" => $key,
					"version" => $version,
					"subuserid" => $subUserId
					);
	    $str_data = json_encode($data);	
		
		$ch = curl_init($APIURL);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $str_data);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
			'Content-Type: application/json',                                                                                
			'Content-Length: ' . strlen($str_data))                                                                       
		);  
		$result = curl_exec($ch);
		
		return $result;
		}
		 catch (Exception $e) 
		 {
			echo 'Caught exception: ',  $e->getMessage(), "\n";
		}
	   
	}
}
?>