
<?php
header('Content-type: text/html; charset=utf-8'); 
class Recruiter {
	/**
	*/
	function SaveUplodedFile()
	{	
	    if($_FILES["resumecontent"]["tmp_name"] )
		{		
		//file should be upto 1 MB you can change as per your need
			if($_FILES["resumecontent"]["size"] < 1048576)
			{
				$explodemainfilename = explode(".",basename($_FILES["resumecontent"]["name"]));
				$countmainexplode = count($explodemainfilename);
				$filterfile = $explodemainfilename[$countmainexplode-1] ;
				
				if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" 
				|| $filterfile== "pdf" || $filterfile == "txt" || $filterfile == "html")
				{
					if ($_FILES["resumecontent"]["error"] > 0)
					{
						$this->_uploaderror.= "<span align='center' class='msg'>Return Code: ".$_FILES["resumecontent"]["error"]."</span><br />";
					}
					else{		
						//explode the name ad append the timestamp
						@$stream=fopen($_FILES["resumecontent"]["tmp_name"],'r');
						$content = stream_get_contents($stream);
						$this->_resumeuploadsucess = "yes";
						$this->_filterfile = $filterfile;
						$filename = basename($_FILES["resumecontent"]["name"]);
						if($filterfile == "rtf" || $filterfile == "doc" || $filterfile == "docx" 
						|| $filterfile == "txt" || $filterfile == "html" || $filterfile== "pdf")
						{
						     echo "Parse";
							$parsedJson = $this->GetJsonOutput($content,$filename);
							return $parsedJson;
						}
						else{
							echo "<span style='color:#FF0000; font-size:12px padding-left:20px;'>There is some problem in parsing resume</span>";
							$upload_result['errorcode'] = 1017;
							return $upload_result;
						}
					}
				}
				else{
					echo "<span style='color:#FF0000; font-size:14px; padding-left:20px; padding-top:10px;' >Invalid file format. Support .doc, .docx, .rtf, .html or .pdf formats</span>";
					$this->_uploaderror.= "<span align='center' class='msg'>Invalid file format. Support .doc, .docx, .rtf, .html or .pdf formats</span>";				 
					$upload_result['errorcode'] = 1016;
				
					return $upload_result;
				}
			}
			else{
				$this->_uploaderror.= "<span align='center' class='msg'>Invalid file.Please upload file upto 1 MB size</span>";	
				
				$upload_result['errorcode'] = 1015;
				
				return $upload_result;
			}
		}
	
		//return true;
	} 
	
	function GetJsonOutput($content='',$type)
	{
	    $ds = new RchilliService();
		$jsonOutput = $ds->resumeParseBinary($content,$type);
		
		$jsonOutput = json_decode($jsonOutput, true);
			$json=$jsonOutput["ResumeParserData"];
			$ResumeFileName=(String) $json["ResumeFileName"];
			
			$FullName=(String) $json["Name"]["FullName"];
			$TitleName=(String) $json["Name"]["TitleName"];
			$FirstName=(String) $json["Name"]["FirstName"];
			$Middlename=(String) $json["Name"]["MiddleName"];
			$LastName=(String) $json["Name"]["LastName"];
			$FormattedName=(String) $json["Name"]["FormattedName"];			
			$DateOfBirth=(String) $json["DateOfBirth"];
			$Gender=(String) $json["Gender"];
			$FatherName=(String) $json["FatherName"];
			$MotherName=(String) $json["MotherName"];
			$MaritalStatus=(String) $json["MaritalStatus"];
			$Nationality=(String) $json["Nationality"];
			$UniqueID=(String) $json["UniqueID"];
			$LicenseNo=(String) $json["LicenseNo"];			
			$PanNo=(String) $json["PanNo"];
			$VisaStatus=(String) $json["VisaStatus"];
			$Category=(String) $json["Category"];
			$SubCategory=(String) $json["SubCategory"];			
			$Qualification=(String) $json["Qualification"];
			$Skills=(String) $json["SkillBlock"];
			$Experience=(String) $json["Experience"];
			$CurrentEmployer=(String) $json["CurrentEmployer"];
			$JobProfile=(String) $json["JobProfile"];
			$GapPeriod=(String) $json["GapPeriod"];
			
			$AverageStay=(String) $json["AverageStay"];
			$LongestStay=(String) $json["LongestStay"];
			$Availability=(String) $json["Availability"];
			$Hobbies=(String) $json["Hobbies"];
			$Objectives=(String) $json["Objectives"];
			$Achievements=(String) $json["Achievements"];
			$References=(String) $json["References"];
			$Summary=(String) $json["Summary"];
			$ExecutiveSummary=(String) $json["ExecutiveSummary"];
			$ManagementSummary=(String) $json["ManagementSummary"];
			$Coverletter=(String) $json["Coverletter"];
			$Certification=(String) $json["Certification"];
			$Publication=(String) $json["Publication"];
			$CustomFields=(String) $json["CustomFields"];
			$DetailResume=(String) $json["DetailResume"];
			$htmlresume=(String) $json["HtmlResume"];
			
			
				//Candidate Image
			$CandidateImageFormat =(String) $json["CandidateImage"]["CandidateImageFormat"];
			$CandidateImageData = (String) $json["CandidateImage"]["CandidateImageData"];
			
			// Template Resume
			$TemplateOutputData=(String) $json["TemplateOutput"]["TemplateOutputData"];
			$TemplateOutputFileName=(String) $json["TemplateOutput"]["TemplateOutputFileName"];
			
			// Work Period
			$TotalExperienceInYear=(String) $json["WorkedPeriod"]["TotalExperienceInYear"];
			$TotalExperienceInMonths=(String) $json["WorkedPeriod"]["TotalExperienceInMonths"];
			$TotalExperienceRange=(String) $json["WorkedPeriod"]["TotalExperienceRange"];
			
			
			
			if(strlen($CandidateImageData)>0)
			{
				print_r("<br/><img src='data:image/".$CandidateImageFormat.";base64,".str_replace(" ","+",$CandidateImageData)."' alt='Base64 encoded image' width='150' height='150'/>");
			}
			echo "<table>";
			
			echo "<tr><td><b>Resume FileName : </b></td><td>". $ResumeFileName ."</td></tr>";
			echo "<tr><td><b>Resume Language : </b></td><td>". $json["ResumeLanguage"]["Language"]."(".$json["ResumeLanguage"]["LanguageCode"].")" ."</td></tr>";

			echo "<tr><td><b>Resume Country : </b></td><td>". $json["ResumeCountry"]["Country"]."
				/".$json["ResumeCountry"]["CountryCode"]["IsoAlpha2"]."/".$json["ResumeCountry"]["CountryCode"]["IsoAlpha3"]."/".$json["ResumeCountry"]["CountryCode"]["UNCode"]."
				(".$json["ResumeCountry"]["Evidence"].")" ."</td></tr>";
			echo "<tr><td><b>Full Name : </b></td><td>". $FullName ."</td></tr>";
			echo "<tr><td><b>Title Name : </b></td><td>". $TitleName ."</td></tr>";
			echo "<tr><td><b>First Name : </b></td><td>". $FirstName ."</td></tr>";
			echo "<tr><td><b>Middle name : </b></td><td>". $Middlename ."</td></tr>";
			echo "<tr><td><b>Last Name : </b></td><td>". $LastName ."</td></tr>";
			echo "<tr><td><b>Formatted Name : </b></td><td>". $FormattedName ."</td></tr>";
			echo "<tr><td><b>DateOfBirth : </b></td><td>". $DateOfBirth ."</td></tr>";
			echo "<tr><td><b>Gender : </b></td><td>". $Gender ."</td></tr>";
			echo "<tr><td><b>Father Name : </b></td><td>". $FatherName ."</td></tr>";
			echo "<tr><td><b>Mother Name : </b></td><td>". $MotherName ."</td></tr>";
			echo "<tr><td><b>Marital Status : </b></td><td>". $MaritalStatus ."</td></tr>";
			echo "<tr><td><b>Nationality : </b></td><td>". $Nationality ."</td></tr>";
			
			echo "<tr><td><b>LanguageKnown : </b></td><td>";
			
			foreach($json["LanguageKnown"] as $LanguageKnown)
			{
				echo $LanguageKnown["Language"] ."(".$LanguageKnown["LanguageCode"]."), ";
			}
			echo"</td></tr>";
			
			
			echo "<tr><td><b>Unique ID : </b></td><td>". $UniqueID ."</td></tr>";
			echo "<tr><td><b>License No : </b></td><td>". $LicenseNo ."</td></tr>";
			echo "<tr><td><b>Passport No : </b></td><td>". $json["PassportDetail"]["PassportNumber"] ."</td></tr>";
			echo "<tr><td><b>Date Of Expiry : </b></td><td>". $json["PassportDetail"]["DateOfExpiry"] ."</td></tr>";
			echo "<tr><td><b>Date Of Issue : </b></td><td>". $json["PassportDetail"]["DateOfIssue"] ."</td></tr>";
			echo "<tr><td><b>Place Of Issue : </b></td><td>". $json["PassportDetail"]["PlaceOfIssue"] ."</td></tr>";
			
			echo "<tr><td><b>Pan No : </b></td><td>". $PanNo ."</td></tr>";
			echo "<tr><td><b>Visa Status : </b></td><td>". $VisaStatus ."</td></tr>";
			echo "<tr><td><b>Email : </b></td><td>";
			
			foreach($json["Email"] as $eml)
			{
				echo $eml["EmailAddress"] .",";
			}
			echo"</td></tr>";
			
			echo "<tr><td><b>PhoneNumber : </b></td><td>";
			
			foreach($json["PhoneNumber"] as $phone)
			{
				echo $phone["FormattedNumber"] ."(".$phone["Type"]."),";
			}
			echo"</td></tr>";
			
			foreach($json["WebSite"] as $Website)
			{
				echo "<tr><td><b>Website : </b></td><td><b>". $Website["Type"] ."</b>:".$Website["Url"]."</td></tr>";
			}
			
			
			foreach($json["Address"] as $address)
			{
				echo "<tr><td><b>".$address["Type"]." Address : </b></td><td>". $address["Street" ] ."</td></tr>";
				echo "<tr><td><b>City: </b></td><td>". $address["City" ] ."</td></tr>";
				echo "<tr><td><b>State : </b></td><td>". $address["State" ]."(" . $address["StateIsoCode" ] .")</td></tr>";
				echo "<tr><td><b>Country : </b></td><td>". $address["Country" ] ."/". $address["CountryCode"]["IsoAlpha2"]."/".$address["CountryCode"]["IsoAlpha3"]."/".$address["CountryCode"]["UNCode"]."</td></tr>";
				echo "<tr><td><b>ZipCode : </b></td><td>". $address["ZipCode" ] ."</td></tr>";
				echo "<tr><td><b>Formatted Address : </b></td><td>". $address["FormattedAddress" ] ."</td></tr>";
			}
			
			echo "<tr><td><b>Category : </b></td><td>". $Category ."</td></tr>";
			echo "<tr><td><b>Current Salary : </b></td><td>".  $json["CurrentSalary"]["Symbol"]." ". $json["CurrentSalary"]["Amount"]. " (".$json["CurrentSalary"]["Currency"].")/".$json["CurrentSalary"]["Unit"]."</td></tr>";
			
			echo "<tr><td><b>ExpectedSalary : </b></td><td>".  $json["ExpectedSalary"]["Symbol"]." ". $json["ExpectedSalary"]["Amount"]. " (".$json["ExpectedSalary"]["Currency"].")/".$json["ExpectedSalary"]["Unit"]."</td></tr>";
			echo "<tr><td><b>Qualification : </b></td><td><textarea rows='5' cols='50'>". $Qualification ."</textarea></td></tr>";
			echo "<tr><td><b>Skills : </b></td><td><textarea rows='5' cols='50'>". $Skills ."</textarea></td></tr>";
			echo "<tr><td><b>Experience : </b></td><td><textarea rows='5' cols='50'>". $Experience ."</textarea></td></tr>";
			echo "<tr><td><b>Current Employer : </b></td><td>". $CurrentEmployer ."</td></tr>";
			echo "<tr><td><b>Job Profile : </b></td><td>". $JobProfile ."</td></tr>";
			echo "<tr><td><b>Gap Period : </b></td><td>". $GapPeriod ."</td></tr>";

			echo "<tr><td><b>CurrentLocation : </b></td><td>";
			foreach($json["CurrentLocation"] as $cloc)
			{
				echo $cloc["City" ] .", ".$cloc["State" ] ."(". $cloc["StateIsoCode" ] .")" .", ".$cloc["Country" ] .",";
			}
			echo"</td></tr>";
			echo "<tr><td><b>PreferredLocation : </b></td><td>";
			foreach($json["PreferredLocation"] as $ploc)
			{
				echo $ploc["City" ] .", ".$ploc["State" ]."(". $ploc["StateIsoCode" ] .")" .", ".$ploc["Country" ] .",";
			}
			echo"</td></tr>";
			
			echo "<tr><td><b>Average Stay : </b></td><td>". $AverageStay ."</td></tr>";
			echo "<tr><td><b>Longest Stay : </b></td><td>". $LongestStay ."</td></tr>";
			echo "<tr><td><b>Availability : </b></td><td>". $Availability ."</td></tr>";
			echo "<tr><td><b>Hobbies : </b></td><td><textarea rows='3' cols='50'>". $Hobbies ."</textarea></td></tr>";
			echo "<tr><td><b>Objectives : </b></td><td><textarea rows='3' cols='50'>". $Objectives ."</textarea></td></tr>";
			echo "<tr><td><b>Achievements : </b></td><td><textarea rows='3' cols='50'>". $Achievements ."</textarea></td></tr>";
			echo "<tr><td><b>References : </b></td><td><textarea rows='3' cols='50'>". $References ."</textarea></td></tr>";
			echo "<tr><td><b>Summary : </b></td><td><textarea rows='3' cols='50'>". $Summary ."</textarea></td></tr>";
			echo "<tr><td><b>Executive Summary : </b></td><td><textarea rows='3' cols='50'>". $ExecutiveSummary ."</textarea></td></tr>";
			echo "<tr><td><b>Management Summary : </b></td><td><textarea rows='3' cols='50'>". $ManagementSummary ."</textarea></td></tr>";
			echo "<tr><td><b>Coverletter : </b></td><td><textarea rows='3' cols='50'>". $Coverletter ."</textarea></td></tr>";
			echo "<tr><td><b>Certification : </b></td><td><textarea rows='3' cols='50'>". $Certification ."</textarea></td></tr>";
			echo "<tr><td><b>Publication : </b></td><td><textarea rows='3' cols='50'>". $Publication ."</textarea></td></tr>";
			echo "<tr><td><b>Detail Resume : </b></td><td><textarea rows='5' cols='50'>". $DetailResume."</textarea></td></tr>";

            echo "</table>";
		
	
		
		
			//Experience
			echo "<b>Experience</b><br/>";
			echo "<table width='100%'>";
			 echo  "<tr>";
				 echo  "<td width='10%'><b>Employer<b></td>";
				 echo  "<td width='10%'><b>JobProfile<b></td>";
				 echo  "<td width='15%'><b>JobLocation<b></td>";
				 echo  "<td width='5%'><b>StartDate<b></td>";
				 echo  "<td width='5%'><b>EndDate<b></td>";
				 echo  "<td width='10%'><b>JobPeriod<b></td>";
				 echo  "<td width='10%'><b>FormattedJobPerio<b></td>";
				 echo  "<td width='25%'><b>JobDescription<b></td>";
				 echo  "</tr>";
			foreach ($json["SegregatedExperience"] as $exp) 
		    {
				 echo  "<tr>";
				 echo  "<td>".$exp["Employer"][ "EmployerName"] ."</td>";
				 echo  "<td>".$exp["JobProfile"]["Title"] ."</td>";
				 echo  "<td>".$exp["Location"]["City"].", ".$exp["Location"]["State"]."(".$exp["Location"]["StateIsoCode"]."), ".$exp["Location"]["Country"] 
						.",<sub>(".$exp["Location"]["CountryCode"]["IsoAlpha2"] ."/".$exp["Location"]["CountryCode"]["IsoAlpha3"] ."/".$exp["Location"]["CountryCode"]["UNCode"] .")</sub></td>";
				 echo  "<td>".$exp["StartDate"] ."</td>";
				 echo  "<td>".$exp["EndDate"] ."</td>";
				 echo  "<td>".$exp["JobPeriod"] ."</td>";
				  echo  "<td>".$exp["FormattedJobPeriod"] ."</td>";
				 echo  "<td><textarea rows='3' cols='50'>".$exp["JobDescription"] ."</textarea></td>";
				 echo  "</tr>";
			}
			echo "</table>";
			
			
			
			//Education
		    echo "<b>Education</b><br/>";
			echo "<table width='100%'>";
			echo  "<tr>";
				 echo  "<td width='15%'><b>Inst.Name<b></td>";
				 echo  "<td width='15%'><b>Inst.City,State,Country<b></td>";
				 echo  "<td width='15%'><b>SubInst.Name<b></td>";
				 echo  "<td width='15%'><b>SubInst.City,State,Country<b></td>";
				 echo  "<td width='10%'><b>Degree<b></td>";
				 echo  "<td width='5%'><b>FormattedDegreePeriod<b></td>";
				 echo  "<td width='5%'><b>StartDate<b></td>";
				 echo  "<td width='5%'><b>EndDate<b></td>";
				 echo  "<td width='5%'><b>Aggregate<b></td>";
				 echo  "</tr>";
			foreach ($json["SegregatedQualification"] as $edu) 
		    {
				echo  "<tr>";
				if(isset($edu["Institution"]))
				{
					echo  "<td>".$edu["Institution"]["Name"] ."<sub>".  $edu["Institution"]["Type"]  ."</sub></td>";
					echo  "<td>".$edu["Institution"]["Location" ]["City"].", ".$edu["Institution"]["Location" ]["State"]."(".$edu["Institution"]["Location" ]["StateIsoCode"]."), "
					.  $edu["Institution"]["Location" ]["Country"]
					."<sub>(". $edu["Institution"]["Location" ]["CountryCode"]["IsoAlpha2"]."/"
					. $edu["Institution"]["Location" ]["CountryCode"]["IsoAlpha3"]."/"
					. $edu["Institution"]["Location" ]["CountryCode"]["UNCode"].")</sub>".
					"</td>";
				}
				else
				{
					echo  "<td> </td>";
					echo  "<td> </td>";
				}
				if(isset($edu["SubInstitution"]))
				{
					echo  "<td>".$edu["SubInstitution"]["Name"] ."<sub>".$edu["SubInstitution"]["Type"]  ."</sub></td>";
					echo  "<td>".$edu["SubInstitution"]["Location" ]["City"].", ".$edu["SubInstitution"]["Location" ]["State"]."(".$edu["SubInstitution"]["Location" ]["StateIsoCode"]."), ". $edu["SubInstitution"]["Location" ]["Country"]
					."<sub>(". $edu["Institution"]["Location" ]["CountryCode"]["IsoAlpha2"]."/"
					. $edu["Institution"]["Location" ]["CountryCode"]["IsoAlpha3"]."/"
					. $edu["Institution"]["Location" ]["CountryCode"]["UNCode"].")</sub>".					
					"</td>";
				}
				else
				{
					echo  "<td> </td>";
					echo  "<td> </td>";
				}
				echo  "<td>".$edu["Degree"]["DegreeName" ]."(". $edu["Degree"]["NormalizeDegree" ].")</td>";
				echo  "<td>".$edu["FormattedDegreePeriod"] ."</td>";
				echo  "<td>".$edu["StartDate"] ."</td>";
				echo  "<td>".$edu["EndDate"] ."</td>";
				if($edu["Aggregate"]["Value"])
				{
					echo  "<td>".$edu["Aggregate"]["Value"] ."<sub>".$edu["Aggregate"]["MeasureType"]."</sub></td>";						
				}
				else
				{
					echo  "<td> </td>";	
				}
				echo  "</tr>";		       
		    }
			echo "</table>";
			
		    echo "</table>";
		    
		
		}	
		
		
		   
}
?>